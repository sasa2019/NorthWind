const path = require('path');
const express = require('express');
const db = require('./db');
const app = express();
const Cost = require('./routes');
const cors = require('cors')
global.Application = app;

app.use(express.static(path.join(__dirname, 'public')))
app.use(express.json())
app.use(cors())

db.Open(app).then((state) => {
    if (state) {
        console.log('DB Server connected')
    }
}).catch((err) => {
    console.log(err)
})

app.use('/api/customers', require('./routes'))

app.get('/db', (req, res) => {
    Cost.getDBs(req, res, app.get('CONNECTION'))
});


app.listen(4000, () => console.log(`Server is running on port 4000`))