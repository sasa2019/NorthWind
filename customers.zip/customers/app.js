window.addEventListener("load", getAllCust);

let currentId = null;

function getAllCust() {
  document.getElementById("details").style.visibility = "none";
  fetch(`http://localhost:4000/api/customers`)
    .then((res) => res.json())
    .then((data) => {
      let output = '<h2 class="mb-4">Customers</h2>';
      data.message.forEach(function (customers) {
        output += `
             <ul class="list-group mb-3">
               <li class="list-group-item"><h6>ID:</h6> ${customers.CustomerID}</li>
               <li class="list-group-item"><h6>Name:<h6> ${customers.CompanyName}</li>
               <button type="button" class="btn btn-info" onclick="getOrders(this)">Orders</button><button class="btn btn-success" onclick="getCust(this)">Get Customer Details</button>
             </ul>
           `;
      });
      document.getElementById('customers').innerHTML = output;
    })
}
function getCust(button) {
  document.getElementById("orders").style.display = "none";
  document.getElementById("orderD").style.display = "none";
  document.getElementById("details").style.visibility = "visible";
  currentId = $(button).siblings('li').first().text().split(': ')[1];
  fetch(`http://localhost:4000/api/customers/${currentId}`)
    .then((res) => res.json())
    .then((data) => {
      let customer = data.message;
      output = `<h2 class="mb-4">Customer Details</h2>
            <ul class="list-group mb-3">
              <li class="list-group-item"><h6>ID:</h6> ${customer.CustomerID}</li>
              <li class="list-group-item"><h6>Company Name:</h6> ${customer.CompanyName}</li>
              <li class="list-group-item"><h6>Contact Name:</h6> ${customer.ContactName}</li>
              <li class="list-group-item"><h6>Contact Title:</h6> ${customer.ContactTitle}</li>
              <li class="list-group-item"><h6>City:</h6> ${customer.City}</li>
              <li class="list-group-item"><h6>Region:</h6> ${customer.Region}</li>
              <li class="list-group-item"><h6>Postal Code:</h6> ${customer.PostalCode}</li>
              <li class="list-group-item"><h6>Country:</h6> ${customer.Country}</li>
              <li class="list-group-item"><h6>Phone:</h6> ${customer.Phone}</li>
              <li class="list-group-item"><h6>Fax:</h6> ${customer.Fax}</li>
            </ul>
          `;
      document.getElementById('details').innerHTML = output;
    })
}

function getOrders(button) {
  document.getElementById("details").style.display = "initial";
  document.getElementById("orders").style.display = "initial";
  document.getElementById("orderD").style.display = "initial";
  document.getElementById("orderD").innerHTML = " ";
  document.getElementById("details").innerHTML = " ";
  currentId = $(button).siblings('li').first().text().split(': ')[1];
  fetch(`http://localhost:4000/api/customers/orders/${currentId}`)
    .then((res) => res.json())
    .then((data) => {
      let orders = data.message;
      let output = `<h2 class="mb-4">Orders for ${currentId}</h2>`;
      data.message.forEach(function (orders) {
        output += `
            <ul class="list-group mb-3">
              <li class="list-group-item"><button style=" background-color: white; color: black; border: 2px solid #4CAF50;" onclick="getOrderD(${orders.OrderID})"><h3>${orders.OrderID}</h3></button></li>
              <li class="list-group-item">Employee ID: ${orders.EmployeeID}</li>   
              <li class="list-group-item">Order Date:${orders.OrderDate}</li>   
              <li class="list-group-item">Required Date: ${orders.RequiredDate}</li>   
              <li class="list-group-item">Shipped Date: ${orders.ShippedDate}</li>   
              <li class="list-group-item">Ship Via: ${orders.ShipVia}</li> 
              <li class="list-group-item">Freight: ${orders.Freight}</li> 
              <li class="list-group-item">Name: ${orders.ShipName}</li> 
              <li class="list-group-item">Address: ${orders.ShipAddress }</li> 
              <li class="list-group-item">City: ${orders.ShipCity}</li>
              <li class="list-group-item">Postal Code: ${orders.ShipPostalCode}</li>
              <li class="list-group-item">Country: ${orders.ShipCountry}</li> 
              </ul>
                 `;
      });
      document.getElementById('orders').innerHTML = output;
    })
}


function getOrderD(OId) {
  let total = 0;
  fetch(`http://localhost:4000/api/customers/orderdetails/${OId}`)
    .then((res) => res.json())
    .then((data) => {
     let orderD = data.message;
      let output = '';
     data.message.forEach(function (orderD) {
      output += `
                     <ul class="list-group mb-3">
                       <li class="list-group-item"><strong><h2 class="mb-4">Order Detalis for ${OId}</h2></strong></li>
                       <li class="list-group-item"><h5>ProductID:</h5>${orderD.ProductID}</li>
                       <li class="list-group-item"><h5>UnitPrice:</h5>${orderD.UnitPrice}</li>
                       <li class="list-group-item"><h5>Quantity:</h5> ${orderD.Quantity}</li>
                          </ul>
                          `;

                          var sum=((orderD.UnitPrice)*(orderD.Quantity));
                          total+=sum;
                    
                          output+= ` <ul class="list-group mb-3">
                          <li class="list-group-item"><h3>Total:</h3> ${total}</li>
                          </ul>
                          `;

       });
       document.getElementById('orderD').innerHTML = output;
    })
}


