const express = require('express')
const router = express.Router()
const handlers = require('./handlers')


router.get('/:id' , (req,res) => {
    handlers.getCost(req,res)
})

router.get('/' , (req,res) => {
    handlers.getAllCost(req,res)
})

router.get('/orders/:id' , (req,res) => {
    handlers.getOrders(req,res)
})

router.get('/orderdetails/:OId' , (req,res) => {
    handlers.getOrderD(req,res)
})


module.exports = router
