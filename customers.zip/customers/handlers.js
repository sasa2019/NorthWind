
const getAllCost = (req, res) => {
    const con = global.Application.get('CONNECTION')
    const sql = `SELECT * FROM customers`
    con.query(sql, (err, result, fields) => {
        if (err) {
            res.json({ state: 'error', message: err.message })
        } else {
            if (result.length > 0) {
                res.json({ state: 'success-all', message: result })
            } else {
                res.json({ state: 'error', message: `No results!!!` })
            }
        }
    })
}

const getCost = (req, res) => {
    const { id } = req.params;
    const con = global.Application.get('CONNECTION')

    const sql = `SELECT * FROM Customers 
           WHERE CustomerID = '${id}'`

    con.query(sql, (err, result, fields) => {
        if (err) {
            res.json({ state: 'error', message: err.message })
        } else {
            if (result.length > 0) {
                res.json({ state: 'success', message: result[0] })
            } else {
                res.json({ state: 'error', message: `${id} not found!!` })
            }
        }
    })
}

const getOrders = (req, res) => {
    const { id } = req.params;
    const con = global.Application.get('CONNECTION')

    const sql = `SELECT * FROM orders 
           WHERE CustomerID = '${id}'`

    con.query(sql, (err, result, fields) => {
        if (err) {
            res.json({ state: 'error', message: err.message })
        } else {
            if (result.length > 0) {
                res.json({ state: 'success', message: result })
            } else {
                res.json({ state: 'error', message: `${id} not found!!` })
            }
        }
    })
}


const getOrderD = (req, res) => {
    const {OId}  = req.params;
    const con = global.Application.get('CONNECTION')
    const OD = '`order details`'
    let OrderID = `OrderID`
    const sql = `SELECT * FROM ${OD} WHERE ${OrderID} = ${OId}`

    con.query(sql, (err, result, fields) => {
        if (err) {
            res.json({ state: 'error', message: err.message })
        } else {
            if (result.length > 0) {
                res.json({ state: 'success', message: result })
            } else {
                res.json({ state: 'error', message: `${OId} not found!!` })
            }
        }
    })
}
    
    

module.exports = {
    getCost,
    getAllCost,
    getOrders,
    getOrderD,
}